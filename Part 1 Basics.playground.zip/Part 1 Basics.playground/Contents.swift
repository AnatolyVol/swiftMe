import UIKit

var greeting = "Hello, playground"

var age = 21
age = 22
age

let name = "Anatoly"
let friend1 = "name1", friend2 = "name2"
friend1
friend2

let myAge = 26
var yourAge = myAge
yourAge

yourAge = 30

//комментарий-строка

/* комментарий
 несколько
 строк */

print("Hello world")
print(yourAge)
print("Мне \(26) лет")



//Homework
let myCount = "This is my first const"
var myVariable = 1408
print(myCount)



